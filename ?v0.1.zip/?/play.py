#!/usr/bin/python3

from binance import Client, ThreadedWebsocketManager, ThreadedDepthCacheManager
import pandas as pd
import datetime
import test as ist



def get_candy():
    #initialise
    ist_date = []
    client = Client()
    pd.set_option('display.max_columns', None)

    #get candles 
    candles = client.get_klines(symbol='BNBBTC', interval=Client.KLINE_INTERVAL_5MINUTE,limit=10)

    #convert candles to dataframe
    cd = pd.DataFrame(candles)

    #set label
    cd.columns = ['time', 'Open', 'High', 'Low', 'Close', 'Volume', 'Close time', 'Quote asset volume', 'Number of trades', 'Taker buy base asset volume', 'Taker buy quote asset volume', 'Can be ignored']

    #convert unix time to gst
    cd["time"] = pd.to_datetime(cd["time"],unit="ms")

    #convert gst to ist
    for i in list(cd["time"]):
        ist_date.append(ist.ist(str(i)))

    dic = {"time":ist_date}
    myd = pd.DataFrame(dic)
    cd["time"] = myd["time"]

    
    #del useless column
    del cd["Close time"],cd['Quote asset volume'],cd['Number of trades'],cd['Taker buy base asset volume'],cd['Taker buy quote asset volume'],cd['Can be ignored']
    return cd


#for j in list(cd["Open time"]):
#    print(j)    
#print(list(cd["Open time"]))
#print(get_candy())
