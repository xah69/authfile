import datetime



def ist(timestamp):
    d=datetime.datetime.strptime(timestamp, "%Y-%m-%d %H:%M:%S") #Get your naive datetime object
    d=d.replace(tzinfo=datetime.timezone.utc) #Convert it to an aware datetime object in UTC time.
    d=d.astimezone() #Convert it to your local timezone (still aware)
    #print(d.strftime("%d %b %Y (%I:%M:%S:%f %p) %Z")) #Print it with a directive of choice
    #print(d.strftime("%Y-%m-%d %I:%M:%S"))
    return d.strftime("%Y-%m-%d %I:%M:%S")

