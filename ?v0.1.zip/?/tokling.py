import play as tg
import time

def to_min(data):
    d = data.split(":")

    hour = int(d[0])
    minute = int(d[1])
    second = int(d[2])

    s2m = second / 60
    h2m = hour * 60

    tom = h2m + minute + s2m

    return int(tom)








while True:
    c = tg.get_candy()
    pti = c["time"].tail(1).item()
    pt = pti.split(" ")


    t = time.localtime()
    ct = time.strftime("%H:%M:%S", t)

    print("[pt]",pt[1]," -- > ",to_min(pt[1])," minute")
    print("[ct]",ct," --> ",to_min(ct)," minute")
    pt_m = to_min(pt[1])
    ct_m = to_min(ct)
    dt = ct_m - pt_m
    print("delta time --> ",dt," minute")
    if dt == 0 or dt == 1:
        for i in range(0,1000000):
            print("calculating")
        continue
    else:
        time.sleep(((5 - dt)*60))


